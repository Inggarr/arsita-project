<?php
// templates/surat/kop_surat.php
// Komponen Kop Surat Resmi UIN Siber Syekh Nurjati Cirebon

$nama_unit_kop = strtoupper(htmlspecialchars($unit_kop ?? ($surat['nama_unit'] ?? 'REKTORAT')));
$alamat_kop    = htmlspecialchars($alamat_kop ?? 'Jl. Perjuangan By Pass Sunyaragi, Kota Cirebon, Jawa Barat 45131 | Website: https://uinssc.ac.id');
?>
<div class="kop">
    <div class="kop-kemenag">KEMENTERIAN AGAMA REPUBLIK INDONESIA</div>
    <div class="kop-univ">UNIVERSITAS ISLAM NEGERI SIBER SYEKH NURJATI CIREBON</div>
    <div class="kop-unit"><?= $nama_unit_kop ?></div>
    <div class="kop-alamat"><?= $alamat_kop ?></div>
</div>
