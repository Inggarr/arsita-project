<?php
// templates/surat/template_surat.php
// Template narasi dasar persuratan dinas berdasarkan jenis surat

function get_template_isi_surat($kode_jenis = 'ST')
{
    switch (strtoupper($kode_jenis)) {
        case 'ST':
            return "Dasar: Surat permohonan / agenda kegiatan dinas kampus.\n\nDengan ini memberikan TUGAS kepada:\nNama : ...\nNIP  : ...\nJabatan : ...\n\nUntuk melaksanakan tugas:\n1. ...\n2. ...\n\nDemikian surat tugas ini diberikan untuk dilaksanakan dengan sebaik-baiknya dan penuh tanggung jawab.";

        case 'SU':
            return "Sehubungan dengan pelaksanaan agenda rapat koordinasi / evaluasi kerja, dengan hormat kami mengundang Bapak/Ibu untuk hadir pada:\n\nHari / Tanggal : ...\nWaktu          : ... WIB s.d. selesai\nTempat         : Ruang Rapat Lt. 2 / Zoom Meeting\nAgenda         : ...\n\nMengingat pentingnya acara ini, kehadiran Bapak/Ibu tepat pada waktunya sangat kami harapkan. Atas perhatian dan kehadirannya diucapkan terima kasih.";

        case 'SE':
            return "Menindaklanjuti kebijakan pimpinan dan dalam rangka optimalisasi tata kelola administrasi kampus, dengan ini kami sampaikan kepada seluruh sivitas akademika beberapa hal sebagai berikut:\n\n1. ...\n2. ...\n3. ...\n\nDemikian surat edaran ini disampaikan untuk menjadi perhatian dan dipedomani sebagaimana mestinya.";

        case 'SP':
            return "Bersama surat ini, kami mengajukan permohonan izin/fasilitasi untuk kegiatan ... yang akan diselenggarakan pada ...\n\nBesar harapan kami permohonan ini dapat disetujui. Atas bantuan dan kerja sama yang baik, kami ucapkan terima kasih.";

        case 'SK':
            return "MENIMBANG:\na. Bahwa dalam rangka kelancaran pelaksanaan tugas ...\nb. Bahwa berdasarkan pertimbangan sebagaimana dimaksud pada huruf a, perlu menetapkan Keputusan ...\n\nMEMUTUSKAN:\nMENETAPKAN:\nKESATU : ...\nKEDUA  : ...\nKETIGA : Keputusan ini berlaku sejak tanggal ditetapkan dengan ketentuan apabila terdapat kekeliruan akan diperbaiki sebagaimana mestinya.";

        default:
            return "Dengan hormat,\n\nSehubungan dengan ... bersama ini kami sampaikan bahwa ...\n\nDemikian surat ini disampaikan. Atas perhatian dan kerja samanya, diucapkan terima kasih.";
    }
}
