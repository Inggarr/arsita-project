CREATE DATABASE IF NOT EXISTS db_arsita CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_arsita;

-- ===== MASTER DATA =====

CREATE TABLE roles (
    id_role INT AUTO_INCREMENT PRIMARY KEY,
    nama_role VARCHAR(50) NOT NULL,
    deskripsi VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE units (
    id_unit INT AUTO_INCREMENT PRIMARY KEY,
    nama_unit VARCHAR(100) NOT NULL,
    kode_unit VARCHAR(20) NOT NULL,
    level ENUM('rektorat','fakultas','prodi') NOT NULL,
    id_parent INT NULL,
    status ENUM('aktif','nonaktif') DEFAULT 'aktif',
    FOREIGN KEY (id_parent) REFERENCES units(id_unit)
) ENGINE=InnoDB;

CREATE TABLE users (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    id_unit INT,
    id_role INT,
    status ENUM('aktif','nonaktif') DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_unit) REFERENCES units(id_unit),
    FOREIGN KEY (id_role) REFERENCES roles(id_role)
) ENGINE=InnoDB;

CREATE TABLE kategori_surat (
    id_kategori INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(100) NOT NULL,
    deskripsi VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE jenis_surat (
    id_jenis_surat INT AUTO_INCREMENT PRIMARY KEY,
    nama_jenis VARCHAR(100) NOT NULL,
    kode_jenis VARCHAR(20),
    keterangan VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE format_nomor (
    id_format INT AUTO_INCREMENT PRIMARY KEY,
    id_unit INT NOT NULL,
    id_jenis_surat INT NOT NULL,
    format_nomor VARCHAR(150) NOT NULL,
    contoh VARCHAR(150),
    aktif TINYINT(1) DEFAULT 1,
    FOREIGN KEY (id_unit) REFERENCES units(id_unit),
    FOREIGN KEY (id_jenis_surat) REFERENCES jenis_surat(id_jenis_surat)
) ENGINE=InnoDB;

-- ===== SURAT MASUK =====

CREATE TABLE surat_masuk (
    id_surat_masuk INT AUTO_INCREMENT PRIMARY KEY,
    no_surat_asal VARCHAR(100),
    tanggal_surat DATE,
    tanggal_terima DATE,
    asal_surat VARCHAR(150),
    perihal VARCHAR(255),
    kategori_id INT,
    jenis_surat_id INT,
    id_unit INT NOT NULL,
    file_surat VARCHAR(255),
    keterangan TEXT,
    asal_disposisi_id INT NULL,
    status_arsip ENUM('belum_ditinjau','ditinjau','didisposisikan','diarsipkan') DEFAULT 'belum_ditinjau',
    dicatat_oleh INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (kategori_id) REFERENCES kategori_surat(id_kategori),
    FOREIGN KEY (jenis_surat_id) REFERENCES jenis_surat(id_jenis_surat),
    FOREIGN KEY (id_unit) REFERENCES units(id_unit),
    FOREIGN KEY (dicatat_oleh) REFERENCES users(id_user)
) ENGINE=InnoDB;

-- ===== SURAT KELUAR =====

CREATE TABLE surat_keluar (
    id_surat_keluar INT AUTO_INCREMENT PRIMARY KEY,
    id_unit INT NOT NULL,
    kategori_id INT,
    jenis_surat_id INT,
    sifat ENUM('biasa','penting','rahasia') DEFAULT 'biasa',
    tujuan VARCHAR(255),
    lampiran VARCHAR(100),
    perihal VARCHAR(255),
    isi_surat TEXT,
    tembusan TEXT,
    tanggal_draft DATE,
    file_draft VARCHAR(255),
    file_final VARCHAR(255),
    status_surat ENUM('draft','menunggu_acc','revisi','disetujui','terkirim','diarsipkan') DEFAULT 'draft',
    dibuat_oleh INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_unit) REFERENCES units(id_unit),
    FOREIGN KEY (kategori_id) REFERENCES kategori_surat(id_kategori),
    FOREIGN KEY (jenis_surat_id) REFERENCES jenis_surat(id_jenis_surat),
    FOREIGN KEY (dibuat_oleh) REFERENCES users(id_user)
) ENGINE=InnoDB;

CREATE TABLE acc_surat_keluar (
    id_acc INT AUTO_INCREMENT PRIMARY KEY,
    id_surat_keluar INT NOT NULL,
    tahap_ke INT NOT NULL,
    disetujui_oleh INT,
    status ENUM('menunggu','disetujui','ditolak') DEFAULT 'menunggu',
    catatan_penolakan TEXT,
    tanggal TIMESTAMP NULL,
    FOREIGN KEY (id_surat_keluar) REFERENCES surat_keluar(id_surat_keluar),
    FOREIGN KEY (disetujui_oleh) REFERENCES users(id_user)
) ENGINE=InnoDB;

CREATE TABLE nomor_surat (
    id_nomor INT AUTO_INCREMENT PRIMARY KEY,
    id_surat_keluar INT NOT NULL,
    nomor_surat VARCHAR(100) NOT NULL,
    tanggal_nomor DATE,
    tahun YEAR,
    id_unit INT,
    id_jenis_surat INT,
    FOREIGN KEY (id_surat_keluar) REFERENCES surat_keluar(id_surat_keluar),
    FOREIGN KEY (id_unit) REFERENCES units(id_unit),
    FOREIGN KEY (id_jenis_surat) REFERENCES jenis_surat(id_jenis_surat)
) ENGINE=InnoDB;

-- ===== DISPOSISI =====

CREATE TABLE disposisi (
    id_disposisi INT AUTO_INCREMENT PRIMARY KEY,
    id_surat_masuk INT NOT NULL,
    dari_user_id INT,
    instruksi TEXT,
    sifat ENUM('biasa','segera','sangat_segera') DEFAULT 'biasa',
    tenggat_waktu DATE NULL,
    catatan TEXT,
    tanggal_kirim TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_surat_masuk) REFERENCES surat_masuk(id_surat_masuk),
    FOREIGN KEY (dari_user_id) REFERENCES users(id_user)
) ENGINE=InnoDB;

CREATE TABLE disposisi_tujuan (
    id_disposisi_tujuan INT AUTO_INCREMENT PRIMARY KEY,
    id_disposisi INT NOT NULL,
    tujuan_tipe ENUM('individu','unit') NOT NULL,
    ke_user_id INT NULL,
    ke_unit_id INT NULL,
    status ENUM('belum_diproses','diproses','selesai') DEFAULT 'belum_diproses',
    FOREIGN KEY (id_disposisi) REFERENCES disposisi(id_disposisi),
    FOREIGN KEY (ke_user_id) REFERENCES users(id_user),
    FOREIGN KEY (ke_unit_id) REFERENCES units(id_unit)
) ENGINE=InnoDB;

CREATE TABLE tindak_lanjut (
    id_tindak_lanjut INT AUTO_INCREMENT PRIMARY KEY,
    id_disposisi_tujuan INT NOT NULL,
    catatan TEXT,
    lampiran VARCHAR(255),
    tanggal_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_disposisi_tujuan) REFERENCES disposisi_tujuan(id_disposisi_tujuan)
) ENGINE=InnoDB;

-- ===== DATA AWAL =====

INSERT INTO roles (nama_role, deskripsi) VALUES
('admin_rektorat', 'Kelola data master global, oversight semua unit'),
('admin_unit', 'Kelola akun dan master data unit sendiri'),
('staff_tu', 'Input surat masuk, buat draft surat keluar'),
('pimpinan', 'ACC surat keluar, buat disposisi, tinjau surat masuk');

INSERT INTO kategori_surat (nama_kategori, deskripsi) VALUES
('Akademik', 'Perkuliahan, penelitian, kurikulum'),
('Kemahasiswaan', 'Organisasi mahasiswa, beasiswa, kedisiplinan'),
('Kepegawaian', 'Dosen dan staff (SK, cuti, tugas dinas)'),
('Keuangan', 'Anggaran, pembayaran, tagihan'),
('Kerjasama', 'MoU, hubungan dengan pihak luar'),
('Umum', 'Administrasi harian, edaran, rapat internal');

INSERT INTO jenis_surat (nama_jenis, kode_jenis) VALUES
('Surat Keputusan', 'SK'),
('Surat Tugas', 'ST'),
('Surat Edaran', 'SE'),
('Surat Undangan', 'SU'),
('Surat Permohonan', 'SP'),
('Surat Pemberitahuan', 'SPB');

INSERT INTO units (nama_unit, kode_unit, level, id_parent) VALUES
('Rektorat', 'UN.14', 'rektorat', NULL),
('Fakultas Ilmu Tarbiyah dan Keguruan', 'Fak.01', 'fakultas', 1),
('Prodi Informatika', 'Prodi.03', 'prodi', 2);