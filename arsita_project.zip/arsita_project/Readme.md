# ARSITA — Arsip Surat Instansi Terintegrasi Antarunit
### Rancangan Sistem Gabungan Lengkap: Persuratan, Penomoran Otomatis, & Disposisi Elektronik UINSSC

*Menggabungkan 3 rancangan awal: ARSITA (M. Inggar Agus Sholihin), Sistem Surat Masuk & Keluar (Abd Kholik), Sistem Disposisi Surat Elektronik (Dicky Dermawan) — dilengkapi hasil pembahasan lanjutan.*

---

## 1. Latar Belakang

Surat masuk dan surat keluar adalah bagian penting dari administrasi kampus. Dalam pengelolaannya ada beberapa proses: pencatatan, penomoran, persetujuan, disposisi, penyimpanan, pencarian, hingga pengarsipan. Selama ini proses tersebut manual dan berbasis kertas, dengan masalah utama:

- Surat fisik harus dicetak dan diantar — lambat.
- Tidak ada cara mengetahui status surat — sulit dilacak.
- Arsip menumpuk — pencarian surat lama sulit.
- Risiko nomor surat bentrok, dobel, atau bolong karena dicatat manual.

Tiga rancangan awal menyasar masalah ini dari sisi berbeda, dan digabung menjadi satu sistem utuh:

| Rancangan | Fokus Utama | Kontribusi ke Sistem Gabungan |
|---|---|---|
| **ARSITA** (Inggar) | Penomoran surat otomatis, multi-unit (Rektorat/Fakultas/Prodi) | Logika inti penomoran, struktur role & alur ACC berjenjang |
| **Sistem Surat Masuk & Keluar** (Kholik) | Pencatatan, pengarsipan, pencarian surat | Kerangka umum alur surat masuk & keluar, struktur menu dasar |
| **Sistem Disposisi Elektronik** (Dicky) | Disposisi surat dari pimpinan ke unit terkait | Modul disposisi, tindak lanjut, dan status pelacakan |

Solusi: mengubah seluruh proses dari manual berbasis kertas menjadi elektronik berbasis web, satu sistem untuk 3 level unit sekaligus (Rektorat, Fakultas, Prodi), dengan penomoran otomatis sebagai inti pembeda dari sistem persuratan biasa.

## 2. Tujuan Sistem

- Menyatukan pencatatan surat masuk, pembuatan surat keluar, disposisi, dan pengarsipan dalam satu sistem.
- Menghilangkan risiko nomor surat bentrok/dobel/bolong lewat penomoran otomatis per unit.
- Mendigitalkan proses disposisi (dari kertas jadi elektronik) sehingga status surat bisa dilacak real-time.
- Mendukung 3 level unit (Rektorat, Fakultas, Prodi) sekaligus dalam satu sistem, dengan data yang terpisah per unit tapi dikelola dalam platform yang sama.
- Mempermudah pencarian arsip dan pembuatan laporan.
- Mengurangi pekerjaan pencatatan yang berulang.

## 3. Manfaat Sistem

**Bagi Kampus**
- Membantu pengelolaan administrasi surat secara terstruktur.
- Mempermudah pencarian arsip, menyimpan dokumen lebih rapi.
- Mendukung pembuatan laporan.

**Bagi Pengguna (Staff TU & Pimpinan)**
- Mempermudah pencatatan dan pembuatan surat.
- Mempercepat pencarian informasi.
- Mengurangi pekerjaan administratif berulang.
- Status surat bisa dilacak real-time, tidak hilang jejak seperti kertas fisik.

**Bagi Mahasiswa (pengembang)**
- Menerapkan analisis dan pengembangan sistem nyata.
- Memahami proses administrasi surat di perguruan tinggi.

## 4. Ruang Lingkup Sistem

Sistem ini punya **dua alur besar yang berjalan terpisah** (Surat Masuk dan Surat Keluar), plus modul pendukung. Disposisi hanya ada di sisi Surat Masuk — tidak masuk ke alur Surat Keluar.

| | Surat Masuk | Surat Keluar |
|---|---|---|
| Asal surat | Dari luar kampus, atau dari unit atasan lewat disposisi | Dibuat sendiri di dalam sistem |
| Perlu ACC/persetujuan? | Tidak | Ya (berjenjang sesuai unit) |
| Perlu nomor otomatis? | Tidak (sudah punya nomor dari pengirim asal) | Ya — inti dari sistem ini |
| Perlu disposisi? | Ya (opsional) | Tidak |
| Berakhir di | Arsip | Arsip |

**A. Surat Masuk**
- Pencatatan & upload dokumen (hasil scan)
- Peninjauan oleh pimpinan
- Disposisi ke pihak/unit terkait (jika diperlukan)
- Pengarsipan (langsung, atau setelah disposisi selesai ditindaklanjuti)

**B. Surat Keluar**
- Pembuatan draft surat lewat form terstruktur
- Generate surat otomatis dalam format A4 siap cetak (seperti dokumen Word/PDF)
- Alur ACC/persetujuan berjenjang (sesuai unit)
- Penomoran otomatis setelah ACC tahap terakhir
- Tanda tangan (digital/manual)
- Pengiriman & pengarsipan

**C. Disposisi**
- Pimpinan membuat disposisi (tujuan, instruksi, sifat, tenggat waktu, catatan tambahan)
- Bisa berjenjang antarunit (Rektorat → Fakultas → Prodi → individu)
- Penerima menerima notifikasi, mengubah status (Belum Diproses → Diproses → Selesai), mengisi catatan/lampiran tindak lanjut
- Pimpinan juga bisa langsung arsipkan surat tanpa disposisi

**D. Master Data & Admin**
- Kelola unit, kategori surat, jenis surat, format nomor per unit
- Kelola akun & role pengguna

**E. Arsip & Pencarian**
- Arsip gabungan surat masuk & keluar
- Pencarian/filter berdasarkan nomor, tanggal, perihal, kategori, unit

**F. Laporan**
- Rekap surat masuk/keluar per periode, per unit, per kategori
- Export ke Excel/PDF

## 5. Bagian-Bagian Surat (Standar Baku)

Surat resmi/dinas punya struktur baku yang jadi acuan field-field di sistem:

1. **Kop surat** — logo instansi, nama instansi, alamat, kontak. Otomatis nempel sesuai unit, tidak diinput manual.
2. **Nomor surat** — digenerate otomatis oleh sistem (inti dari ARSITA).
3. **Lampiran** — jumlah dokumen tambahan yang disertakan (isi "-" jika tidak ada).
4. **Perihal/Hal** — judul singkat isi surat.
5. **Tanggal surat** — otomatis ambil tanggal sistem, bisa diedit.
6. **Tujuan/alamat surat** — "Kepada Yth. ..." nama & jabatan penerima.
7. **Isi surat** — pembuka, isi pokok (maksud & tujuan), penutup.
8. **Tanda tangan & nama terang pengirim** — plus jabatan dan cap/stempel instansi.
9. **Tembusan** (opsional) — daftar pihak lain yang juga menerima salinan.

Field-field ini menjadi dasar rancangan form input di sistem, baik untuk surat masuk (dicatat identitasnya saja) maupun surat keluar (diisi lengkap untuk digenerate jadi dokumen jadi).

## 6. Pengguna & Role

| Role | Tugas |
|---|---|
| **Staff TU / Admin Unit** | Input surat masuk, buat draft surat keluar, kirim untuk ACC, kelola arsip |
| **Pimpinan (Kajur / Dekan-Wakil Dekan / Kasubbag-Kabag-Rektor)** | Baca surat, buat disposisi, ACC surat keluar sesuai jenjang unit masing-masing |
| **Penerima Disposisi** | Terima instruksi, tindak lanjuti, update status & catatan |
| **Admin Rektorat** | Kelola data master global (unit, kategori, jenis surat, format nomor), oversight semua unit |
| **Admin Fakultas/Prodi** | Kelola akun & data master untuk scope unit sendiri |

Alur ACC berjenjang per unit:
- **Prodi**: ACC 1 tahap (Kajur)
- **Fakultas**: ACC 1 tahap (Dekan/Wakil Dekan)
- **Rektorat**: ACC berjenjang 3 tahap (Kasubbag → Kabag → Rektor)

## 7. Alur Surat Masuk (Detail Lengkap)

### 7.1 Langkah demi langkah

1. **Surat fisik diterima** — datang dari instansi luar, unit lain, atau perorangan. Masih di dunia nyata, belum masuk sistem.
2. **Discan** — admin memindai/memfoto surat kertas jadi file digital (PDF/JPG) pakai scanner/mesin fotokopi/HP, biar isinya bisa dilihat lewat sistem tanpa pegang kertas asli.
3. **Login & buka form "Input Surat Masuk"** — admin masuk ke aplikasi.
4. **Dicatat admin** — admin mengetik data identitas surat ke form: nomor surat asli (dari pengirim), tanggal surat, pengirim/asal instansi, perihal, kategori surat. *Ini bukan menyalin ulang isi surat, hanya info identitasnya.*
5. **Upload file hasil scan** — file dari langkah 2 diunggah, jadi lampiran digital yang menempel ke data surat.
6. **Simpan** — data & file tersimpan di database, siap dicari, ditinjau pimpinan, atau didisposisikan.

### 7.2 Alur setelah tercatat

```
Surat Diterima → Discan → Dicatat Admin (+upload) → Data Disimpan
   → Ditinjau Pimpinan → [Perlu Disposisi?]
        → Ya: Buat Disposisi → Ditindaklanjuti Penerima → Arsip
        → Tidak: Arsipkan Langsung → Arsip
```

## 8. Alur Disposisi (Detail Lengkap)

### 8.1 Sumber disposisi

Disposisi **tidak hanya berlaku untuk surat dari luar kampus** — disposisi juga berlaku antarunit internal secara berjenjang:

```
Surat dari luar kampus
        ↓
   Diterima Rektorat (surat masuk #1)
        ↓ (Rektor disposisikan ke Fakultas terkait)
   Jadi surat masuk baru di Fakultas (surat masuk #2, sumber: "disposisi dari Rektorat")
        ↓ (Dekan disposisikan ke Prodi terkait)
   Jadi surat masuk baru di Prodi (surat masuk #3, sumber: "disposisi dari Fakultas")
        ↓ (Kajur disposisikan ke dosen/staff)
   Ditindaklanjuti oleh individu
```

Setiap kali surat "turun" ke unit di bawahnya lewat disposisi, surat itu otomatis tercatat sebagai entri surat masuk baru di unit tersebut — lengkap dengan riwayat asal disposisinya. Tujuan disposisi bisa berupa:
- **Individu** (langsung ke satu staff) → berhenti di situ, tidak bisa didisposisikan lagi.
- **Unit** (misal ke Fakultas tertentu) → begitu diterima, otomatis jadi record baru di surat masuk unit itu, dan pimpinan unit itu bisa mendisposisikan lagi ke bawah.

### 8.2 Disposisi tidak membuat nomor baru

Disposisi **bukan surat baru** — nomor suratnya tetap yang asli dari pengirim pertama. Disposisi hanyalah instruksi yang menempel ke surat yang sama saat berpindah tangan/unit.

### 8.3 Field-field disposisi

Yang **diisi manual oleh pemberi disposisi**:

| Field | Wajib/Opsional | Keterangan |
|---|---|---|
| **Tujuan** | Wajib | Siapa/unit mana yang dituju |
| **Instruksi** | Wajib | Apa yang harus dilakukan penerima, mis. "Mohon ditindaklanjuti", "Untuk diketahui saja" |
| **Sifat** | Wajib | Biasa / Segera / Sangat Segera |
| **Tenggat waktu** | Opsional | Deadline jika instruksi bersifat urgent |
| **Catatan tambahan** | Opsional | Konteks tambahan dari pemberi disposisi |

Yang **otomatis diisi/dijalankan sistem** (bukan diisi manual):

| Field | Keterangan |
|---|---|
| **Status** | Belum Diproses → Diproses → Selesai. Diupdate oleh penerima, bukan diisi pemberi disposisi. |
| **Tanggal kirim** | Otomatis timestamp saat disposisi dikirim. |

Bedanya "disposisi beneran" vs "sekadar geser surat": **disposisi = surat + instruksi + status yang bisa dilacak**. Tanpa instruksi dan status yang bisa diupdate, itu cuma pemindahan biasa.

### 8.4 Alur status disposisi

```
Notifikasi Disposisi Masuk → Buka & Baca Instruksi
   → Ubah Status "Diproses" → Laksanakan Instruksi
   → Isi Catatan/Keterangan (+lampiran bukti jika ada) → Ubah Status "Selesai"
```

## 9. Alur Surat Keluar (Detail Lengkap)

### 9.1 Form "Buat Surat Keluar" — field otomatis vs manual

**Bagian OTOMATIS (sistem yang isi):**

| Field | Sumber |
|---|---|
| Kop surat (logo, nama instansi, alamat) | Diambil dari `unit_id` akun yang login |
| Nomor surat | Kosong saat draft, digenerate otomatis setelah ACC final |
| Tanggal surat | Tanggal sistem saat ini (bisa diedit) |
| Nama & jabatan penandatangan | Diambil dari data user/pimpinan yang ACC & TTD |

**Bagian MANUAL (diisi penulis surat):**

| Field | Keterangan |
|---|---|
| Jenis surat | Dropdown: SK, Surat Tugas, Edaran, Undangan, Permohonan, Pemberitahuan |
| Kategori surat | Dropdown: Akademik, Kemahasiswaan, Kepegawaian, Keuangan, Kerjasama, Umum (untuk filter/pencarian) |
| Sifat surat | Biasa / Penting / Rahasia |
| Tujuan surat | "Kepada Yth. [nama & jabatan penerima]" |
| Lampiran | Jumlah dokumen tambahan (isi "-" jika tidak ada) |
| Perihal | Judul singkat isi surat |
| Isi surat | Textarea — pembuka, isi pokok, penutup (bisa disediakan template per jenis surat) |
| Tembusan (opsional) | Daftar pihak lain yang juga menerima salinan |
| Lampiran file pendukung (opsional) | Upload dokumen pendukung jika ada |

### 9.2 Dua pilihan submit setelah form diisi

Di bagian bawah form ada 2 tombol:

**Opsi 1: "Simpan sebagai Draft"**
- Status = Draft. Belum dikirim ke atasan, belum terlihat siapapun selain pembuatnya.
- Cocok kalau isi surat belum yakin final.

**Opsi 2: "Ajukan Persetujuan" / "Kirim untuk ACC"**
- Data disimpan sekaligus langsung dikirim ke atasan, status = Menunggu ACC.
- Notifikasi muncul ke akun atasan berwenang.
- Surat tidak bisa diedit lagi kecuali ditolak dulu.

```
[Form diisi lengkap]
        ↓
   ┌──────────────┬──────────────────────┐
   │ Simpan Draft │ Ajukan Persetujuan   │
   └──────────────┴──────────────────────┘
         ↓                     ↓
   Status: Draft       Status: Menunggu ACC
   (bisa diedit bebas)  (menunggu atasan ACC)
```

Kalau memilih "Simpan Draft" duluan, di halaman detail surat nanti muncul tombol "Ajukan Persetujuan" untuk lanjut ke tahap ACC.

### 9.3 Navigasi setelah submit

1. User isi form → klik "Simpan/Generate" → data tersimpan status Draft, sistem generate preview PDF (kop otomatis, nomor masih placeholder).
2. User diarahkan ke halaman **Detail/Preview Surat** — bukan langsung ke dashboard. Ada preview PDF, info status, tombol Edit/Hapus/Ajukan Persetujuan.
3. User klik "Kirim untuk Persetujuan" → status jadi "Menunggu ACC", sistem catat siapa atasan yang harus ACC (sesuai unit), notifikasi terkirim.
4. User diarahkan balik ke **Riwayat Surat Keluar** — daftar semua surat yang pernah dibuat, surat baru muncul di atas dengan status "Menunggu ACC".
5. Di sisi lain, atasan login → buka menu "Persetujuan Surat" → klik surat itu → baca isi → Setuju/Tolak.

### 9.4 Alur ACC: Setuju atau Tolak

**Kalau atasan klik "Setuju":**
- ACC 1 tahap (Prodi/Fakultas) → langsung final, nomor otomatis digenerate, surat siap TTD.
- ACC berjenjang (Rektorat, 3 tahap) → status jadi "Disetujui Kasubbag" → lanjut Kabag → lanjut Rektor. Nomor baru keluar setelah tahap terakhir (Rektor) ACC.

**Kalau atasan klik "Tolak":**
- Atasan wajib isi catatan alasan penolakan (mis. "perihal kurang jelas", "salah tujuan surat").
- Status surat balik jadi Draft dengan tanda "Revisi diperlukan" + catatan alasan.
- Staff TU edit surat sesuai catatan, ajukan ulang → status balik ke "Menunggu ACC" dari awal.

```
Draft → Ajukan → Ditolak + catatan → Revisi → Ajukan lagi → ... → Disetujui → Nomor Otomatis → TTD → Arsip
```

*Catatan untuk observasi lanjutan: kalau di Rektorat sudah di-ACC Kasubbag lalu ditolak Kabag, apakah balik ke Draft dari nol atau cukup revisi lalu diajukan ulang ke Kasubbag saja (tanpa hilang status ACC sebelumnya) — perlu dikonfirmasi ke pihak kampus.*

### 9.5 Diagram alur surat keluar (ringkas)

```
Draft Dibuat (Staff TU)
   → Dikirim untuk Persetujuan
   → ACC oleh Atasan (1 tahap atau berjenjang sesuai unit)
        → Ditolak → Perbaikan Surat → kembali ke Draft/Persetujuan
        → Disetujui (tahap terakhir) → Nomor Digenerate Otomatis
   → Tanda Tangan (digital/cetak fisik)
   → Pengiriman
   → Surat Final Tersimpan / Diarsipkan
```

## 10. Generate Surat Otomatis ke Format A4 (Word/PDF)

Ini bagian teknis dari ide "isi form terus jadi surat kayak di Word": konsepnya adalah **template surat + mail merge**, praktik standar di sistem persuratan digital.

### 10.1 Konsepnya

1. Sistem punya **template surat per unit** — didesain sekali di awal, ukuran A4, sudah ada kop, margin, font, posisi nomor/tanggal/tanda tangan.
2. Field yang diisi user di form (jenis, tujuan, perihal, isi surat, dst) "ditempel" otomatis ke posisi yang sesuai di template saat user klik "Selanjutnya"/"Generate Surat".
3. Hasilnya keluar sebagai file siap lihat/cetak, umumnya **format PDF** (bukan .docx asli) karena:
   - Layout tidak berantakan di device/versi berbeda (beda dengan Word yang bisa geser tergantung font/versi).
   - Tidak bisa diedit sembarangan setelah jadi surat resmi.
   - Bisa langsung dicetak dalam ukuran A4 yang pas.

### 10.2 Alur teknisnya

```
Form Buat Surat (HTML form)
   → Submit ke PHP → Simpan ke tabel surat_keluar (status: draft)
   → ...alur ACC...
   → Setelah ACC final: PHP generate nomor dari tabel format_nomor
   → PHP ambil data surat + isi ke template HTML
   → Dompdf render HTML itu → jadi file PDF
   → PDF disimpan di server, link download muncul di dashboard
```

### 10.3 Cara implementasi (sesuai stack PHP/MySQL)

- **Buat template surat dalam HTML+CSS**, ukuran A4 (`@page { size: A4; }`), berisi placeholder seperti `{{nomor_surat}}`, `{{perihal}}`, `{{isi_surat}}`, dll.
- Saat generate, PHP ambil data dari database dan mengganti placeholder itu dengan data asli.
- Convert HTML jadi PDF pakai salah satu library:
  - **Dompdf** — murni PHP, `composer require dompdf/dompdf`, paling gampang.
  - **mPDF** — mirip Dompdf, support CSS lebih lengkap.
  - **wkhtmltopdf** (dipanggil via shell command dari PHP) — hasil render paling akurat untuk template kompleks.

### 10.4 Catatan penting

- Preview sebelum ACC final akan menunjukkan nomor surat kosong/placeholder — nomor asli baru ditempel setelah ACC final (sesuai alur di Bagian 9.4).
- Kalau nanti ada tanda tangan digital, itu ditempel belakangan setelah PDF jadi (bisa berupa gambar TTD + QR code validasi, atau e-sign resmi).

## 11. Logika Penomoran Surat Otomatis (Inti dari ARSITA)

Bagian yang paling membedakan sistem ini dari rancangan persuratan biasa:

1. Sistem mengecek kombinasi: **unit + jenis surat + tahun** — ini yang menentukan counter (kategori surat *tidak* dipakai untuk hitungan nomor, hanya untuk pencarian/filter).
2. Sistem mencari nomor terakhir yang pernah dipakai untuk kombinasi tersebut di database.
3. Nomor tersebut ditambah 1.
4. Nomor baru ditempel ke format lengkap sesuai kode unit (contoh: `UN.14` untuk Rektorat, `Fak.01` untuk Fakultas, `Prodi.03` untuk Prodi).
5. Nomor terkunci begitu tersimpan — tidak dipakai ulang meskipun surat dibatalkan (mencegah nomor bolong/kembar).

**Catatan teknis:** proses ini pakai *transaction/row locking* di database agar tidak ada 2 surat mendapat nomor sama saat diinput bersamaan. Nomor baru digenerate otomatis **tepat setelah ACC disetujui di tahap terakhir** — bukan pas draft dibuat.

### Perbedaan Perlakuan per Unit

| Aspek | Rektorat | Fakultas | Prodi |
|---|---|---|---|
| Kode unit di nomor surat | UN.14 (contoh) | Fak.01 (contoh) | Prodi.03 (contoh) |
| Hitungan nomor | Terpisah sendiri | Terpisah sendiri | Terpisah sendiri |
| Akses lihat data | Bisa lihat semua unit | Hanya fakultasnya sendiri | Hanya prodinya sendiri |
| Alur ACC/persetujuan | Berjenjang (Kasubbag→Kabag→Rektor) | 1 tahap (Dekan) | 1 tahap (Kajur) |

## 12. Rancangan Database (Gabungan)

| Tabel | Atribut Utama |
|---|---|
| **users** | id, nip_nim, nama, username, password, role, unit_id |
| **unit** | id, nama_unit, kode_unit, tipe (Rektorat/Fakultas/Prodi), parent_unit_id |
| **kategori_surat** | id, nama_kategori (Akademik, Kemahasiswaan, Kepegawaian, Keuangan, Kerjasama, Umum) |
| **jenis_surat** | id, nama_jenis (SK, Surat Tugas, Edaran, Undangan, Permohonan, Pemberitahuan) |
| **format_nomor** | id, unit_id, jenis_surat_id, tahun, counter_terakhir |
| **surat_masuk** | id, nomor_surat_asli, tanggal_terima, pengirim, perihal, file_scan, kategori_id, dicatat_oleh, unit_id, asal_disposisi_id (nullable, FK ke disposisi_tujuan jika berasal dari disposisi unit atasan), status |
| **surat_keluar** | id, nomor_surat, tanggal_surat, kategori_id, jenis_surat_id, sifat, tujuan, lampiran, perihal, isi, tembusan, file_draft, file_final, dibuat_oleh, unit_id, status |
| **acc_surat_keluar** | id, surat_keluar_id, tahap_ke, disetujui_oleh, status (Menunggu/Disetujui/Ditolak), catatan_penolakan, tanggal |
| **disposisi** | id, surat_masuk_id, dibuat_oleh, instruksi, sifat, tenggat_waktu, catatan_tambahan, tanggal_kirim |
| **disposisi_tujuan** | id, disposisi_id, tujuan_tipe (individu/unit), user_id (nullable), unit_id (nullable), status |
| **tindak_lanjut** | id, disposisi_tujuan_id, catatan, lampiran, tanggal_update |
| **arsip** | id, tipe (masuk/keluar), referensi_id, tanggal_arsip |

**Relasi kunci:**
- `surat_keluar.unit_id` + `jenis_surat_id` + `tahun` → dipakai `format_nomor` untuk generate nomor otomatis.
- `surat_keluar` → `acc_surat_keluar` (1-N) untuk mendukung ACC berjenjang di Rektorat.
- `surat_masuk` → `disposisi` (1-N) → `disposisi_tujuan` (1-N) → `tindak_lanjut` (1-1).
- `disposisi_tujuan.unit_id` terisi jika tujuan disposisi adalah unit (bukan individu) → memicu pembuatan record baru di `surat_masuk` milik unit itu, dengan `asal_disposisi_id` menunjuk balik ke `disposisi_tujuan` asal.

## 13. Daftar Fitur Sistem (Gabungan Lengkap)

**Login & Akses**
- Login, deteksi otomatis unit & role, pembatasan akses per role/unit

**Surat Masuk**
- Tambah/edit/hapus surat masuk, upload file scan, disposisi surat, riwayat & pencarian

**Surat Keluar**
- Buat draft lewat form terstruktur (field otomatis + manual)
- Simpan Draft / Ajukan Persetujuan
- Alur ACC (1 tahap atau berjenjang), tolak dengan catatan revisi
- Generate nomor otomatis, generate dokumen A4 (PDF)
- Tanda tangan, cetak/download, edit sebelum ACC final

**Disposisi**
- Buat disposisi (tujuan, instruksi, sifat, tenggat, catatan), termasuk disposisi berjenjang antarunit
- Notifikasi ke penerima, update status & catatan tindak lanjut

**Arsip & Pencarian**
- Arsip gabungan surat masuk & keluar, filter berdasarkan unit/jenis/kategori/tanggal

**Master Data (Admin)**
- Kelola unit, kategori surat, jenis surat, format nomor per unit, kelola akun

**Laporan**
- Rekap surat masuk/keluar per bulan/tahun/unit/kategori, export Excel/PDF

## 14. Rancangan Menu Aplikasi per Role

```
LOGIN
 └─ DASHBOARD (beda tampilan per role)
     ├─ Admin/Staff TU: Surat Masuk | Surat Keluar (Buat/Draft/Riwayat) | Arsip | Laporan
     ├─ Pimpinan: Surat Masuk (Tinjau+Disposisi) | Persetujuan Surat Keluar (ACC) | Riwayat Disposisi
     ├─ Penerima Disposisi: Disposisi Masuk | Riwayat Tugas
     └─ Admin Rektorat: + Master Data (Unit, Kategori, Jenis Surat, Format Nomor, Akun)
```

## 15. Rencana Observasi / Validasi Lanjutan

1. Konfirmasi jumlah tahap ACC riil di tiap unit (apakah selalu sama seperti asumsi di atas).
2. Konfirmasi format nomor surat resmi kampus per unit (contoh nomor asli, bukan hanya UN.14/Fak.01).
3. Konfirmasi siapa saja yang berwenang membuat disposisi vs hanya menerima.
4. Cek kebutuhan sifat surat (Biasa/Penting/Rahasia) — apakah memengaruhi hak akses lihat dokumen.
5. Cek kebutuhan tanda tangan digital (perlu sertifikat elektronik?) atau cukup upload hasil TTD basah yang di-scan.
6. Validasi struktur tabel `format_nomor` dengan pola penomoran surat yang benar-benar berlaku di UINSSC.
7. Konfirmasi perilaku penolakan ACC berjenjang di Rektorat: balik ke Draft dari nol, atau revisi lalu lanjut dari tahap yang ditolak saja.
8. Konfirmasi template surat resmi per unit (kop, margin, posisi elemen) untuk kebutuhan generate PDF.

---
*Dokumen ini adalah hasil penggabungan tiga rancangan awal ditambah seluruh detail hasil diskusi lanjutan, untuk keperluan tugas magang/kuliah. Detail final (struktur tabel, alur ACC, format nomor, template surat) perlu divalidasi lewat observasi lapangan sebelum masuk tahap implementasi.*
