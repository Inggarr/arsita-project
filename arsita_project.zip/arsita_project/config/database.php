<?php
// Koneksi database ARSITA (pakai PDO biar aman dari SQL Injection)

$host     = 'localhost';
$db_name  = 'db_arsita';
$username = 'root';   // default Laragon
$password = '';       // default Laragon kosong

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db_name;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}