<?php
// Konstanta global aplikasi ARSITA

define('APP_NAME', 'ARSITA');
define('BASE_URL', '/arsita_project/public');
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5 MB

date_default_timezone_set('Asia/Jakarta');

if (ob_get_level() === 0) {
    ob_start();
}