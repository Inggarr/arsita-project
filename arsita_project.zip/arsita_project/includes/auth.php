<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

// Wajib sudah login, kalau belum dilempar ke halaman login
function wajib_login()
{
    if (!isset($_SESSION['id_user'])) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

// Wajib login DAN punya salah satu role yang diizinkan
function wajib_role(array $role_diizinkan)
{
    wajib_login();
    if (!in_array($_SESSION['role'], $role_diizinkan)) {
        http_response_code(403);
        die('Akses ditolak: role Anda tidak berhak membuka halaman ini.');
    }
}