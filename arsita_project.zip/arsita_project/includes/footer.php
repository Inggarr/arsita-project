<?php
// includes/footer.php
?>
    </main>
</div>

<!-- ARSITA Notification System -->
<script src="<?= BASE_URL ?>/assets/js/notifications.js"></script>
<script>
// Proses flash message dari PHP session → toast
(function() {
    var flashEl = document.getElementById('arsita-flash-data');
    if (flashEl) {
        var type = flashEl.getAttribute('data-type');
        var msg  = flashEl.getAttribute('data-message');
        if (type && msg) {
            // Sedikit delay agar animasi terlihat smooth setelah page load
            setTimeout(function() { arsitaToast(type, msg); }, 300);
        }
        flashEl.remove();
    }
})();
</script>

</body>
</html>
