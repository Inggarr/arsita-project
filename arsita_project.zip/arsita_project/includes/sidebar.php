<?php
// includes/sidebar.php
$current_uri = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
$role        = $_SESSION['role'] ?? '';
$id_user     = (int)($_SESSION['id_user'] ?? 0);
$id_unit     = (int)($_SESSION['id_unit'] ?? 0);
$user_unit   = $_SESSION['nama_unit'] ?? 'UINSSC';
$user_name   = $_SESSION['nama'] ?? 'Pengguna';

// Helper pengecekan URL aktif yang tangguh untuk semua sub-halaman
if (!function_exists('is_sidebar_active')) {
    function is_sidebar_active($patterns, $current_uri) {
        if (!is_array($patterns)) {
            $patterns = [$patterns];
        }
        foreach ($patterns as $pattern) {
            if (strpos($current_uri, $pattern) !== false) {
                return true;
            }
        }
        return false;
    }
}

// Cek status aktif per modul
$is_dashboard_active = is_sidebar_active(['dashboard.php'], $current_uri) 
    || rtrim($current_uri, '/') === rtrim(BASE_URL, '/') 
    || $current_uri === BASE_URL . '/index.php';

$is_sm_active = is_sidebar_active(['/surat_masuk/'], $current_uri);
$is_sk_active = is_sidebar_active(['/surat_keluar/'], $current_uri);

$is_disp_detail = is_sidebar_active(['/disposisi/detail.php'], $current_uri);
$from_param     = $_GET['from'] ?? '';

$is_disp_masuk_active = is_sidebar_active(['/disposisi/masuk.php', '/disposisi/tindak_lanjut.php'], $current_uri)
    || ($is_disp_detail && $from_param === 'masuk');

$is_disp_riwayat_active = is_sidebar_active(['/disposisi/riwayat.php', '/disposisi/buat.php'], $current_uri)
    || ($is_disp_detail && !$is_disp_masuk_active);

$is_acc_active     = is_sidebar_active(['/persetujuan/'], $current_uri);
$is_arsip_active     = is_sidebar_active(['/arsip/'], $current_uri);
$is_laporan_active   = is_sidebar_active(['/laporan/'], $current_uri);
$is_penomoran_active = is_sidebar_active(['/penomoran/'], $current_uri);

// Master Data
$is_master_unit  = is_sidebar_active(['/master/unit.php'], $current_uri);
$is_master_kat   = is_sidebar_active(['/master/kategori.php'], $current_uri);
$is_master_jenis = is_sidebar_active(['/master/jenis.php', '/master/jenis_surat.php'], $current_uri);
$is_master_nomor = is_sidebar_active(['/master/format_nomor.php'], $current_uri);
$is_pengguna     = is_sidebar_active(['/pengguna/'], $current_uri);

// Hitung badge notifikasi secara aman
$badge_acc = 0;
$badge_disp_masuk = 0;
$badge_sm_baru = 0;

if (isset($pdo) && $pdo instanceof PDO) {
    try {
        // Badge ACC untuk pimpinan & admin rektorat
        if (in_array($role, ['pimpinan', 'admin_rektorat'])) {
            if ($role === 'admin_rektorat') {
                $badge_acc = (int)$pdo->query("SELECT COUNT(*) FROM acc_surat_keluar WHERE status = 'menunggu'")->fetchColumn();
            } else {
                $stmtAcc = $pdo->prepare("SELECT COUNT(*) FROM acc_surat_keluar WHERE status = 'menunggu' AND disetujui_oleh = ?");
                $stmtAcc->execute([$id_user]);
                $badge_acc = (int)$stmtAcc->fetchColumn();
            }
        }

        // Badge Disposisi Masuk belum diproses
        if (in_array($role, ['staff_tu', 'pimpinan', 'admin_rektorat', 'admin_unit'])) {
            $stmtDisp = $pdo->prepare("
                SELECT COUNT(*) 
                FROM disposisi_tujuan dt 
                WHERE (dt.ke_user_id = ? OR (dt.tujuan_tipe = 'unit' AND dt.ke_unit_id = ?)) 
                  AND dt.status = 'belum_diproses'
            ");
            $stmtDisp->execute([$id_user, $id_unit]);
            $badge_disp_masuk = (int)$stmtDisp->fetchColumn();
        }

        // Badge Surat Masuk belum ditinjau
        if (in_array($role, ['admin_rektorat', 'staff_tu', 'pimpinan'])) {
            if ($role === 'admin_rektorat') {
                $badge_sm_baru = (int)$pdo->query("SELECT COUNT(*) FROM surat_masuk WHERE status_arsip = 'belum_ditinjau'")->fetchColumn();
            } else {
                $stmtSm = $pdo->prepare("SELECT COUNT(*) FROM surat_masuk WHERE id_unit = ? AND status_arsip = 'belum_ditinjau'");
                $stmtSm->execute([$id_unit]);
                $badge_sm_baru = (int)$stmtSm->fetchColumn();
            }
        }
    } catch (\Throwable $e) {
        // Abaikan error count jika koneksi DB belum siap
    }
}
?>
<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="sidebar-logo">
            <i class="bi bi-shield-check"></i>
        </div>
        <div>
            <div class="sidebar-title">ARSITA</div>
            <div class="sidebar-sub">Disposisi &amp; Persuratan</div>
        </div>
    </div>

    <div class="sidebar-menu">
        <!-- Menu Utama -->
        <div class="menu-category">Utama</div>
        <a href="<?= BASE_URL ?>/dashboard.php" class="menu-item <?= $is_dashboard_active ? 'active' : '' ?>">
            <i class="bi bi-grid-1x2-fill"></i>
            <span class="menu-label">Dashboard</span>
        </a>

        <!-- Persuratan (Surat Masuk & Keluar) -->
        <?php if (in_array($role, ['admin_rektorat', 'staff_tu', 'pimpinan'])): ?>
            <div class="menu-category">Persuratan</div>
            <a href="<?= BASE_URL ?>/surat_masuk/index.php" class="menu-item <?= $is_sm_active ? 'active' : '' ?>" title="Surat Masuk">
                <i class="bi bi-inbox-fill"></i>
                <span class="menu-label">Surat Masuk</span>
                <?php if ($badge_sm_baru > 0): ?>
                    <span class="menu-badge" title="<?= $badge_sm_baru ?> belum ditinjau"><?= $badge_sm_baru ?></span>
                <?php endif; ?>
            </a>
            <a href="<?= BASE_URL ?>/surat_keluar/index.php" class="menu-item <?= $is_sk_active ? 'active' : '' ?>" title="Surat Keluar">
                <i class="bi bi-send-fill"></i>
                <span class="menu-label">Surat Keluar</span>
            </a>
        <?php endif; ?>

        <!-- Disposisi -->
        <?php 
        $can_see_disp_masuk = in_array($role, ['staff_tu', 'pimpinan', 'admin_rektorat', 'admin_unit']);
        $can_see_disp_riwayat = in_array($role, ['pimpinan', 'admin_rektorat']);
        if ($can_see_disp_masuk || $can_see_disp_riwayat): 
        ?>
            <div class="menu-category">Disposisi</div>
            <?php if ($can_see_disp_masuk): ?>
                <a href="<?= BASE_URL ?>/disposisi/masuk.php" class="menu-item <?= $is_disp_masuk_active ? 'active' : '' ?>" title="Disposisi Masuk">
                    <i class="bi bi-card-checklist"></i>
                    <span class="menu-label">Disposisi Masuk</span>
                    <?php if ($badge_disp_masuk > 0): ?>
                        <span class="menu-badge" title="<?= $badge_disp_masuk ?> belum diproses"><?= $badge_disp_masuk ?></span>
                    <?php endif; ?>
                </a>
            <?php endif; ?>
            <?php if ($can_see_disp_riwayat): ?>
                <a href="<?= BASE_URL ?>/disposisi/riwayat.php" class="menu-item <?= $is_disp_riwayat_active ? 'active' : '' ?>" title="Riwayat Disposisi Dibuat">
                    <i class="bi bi-send-check-fill"></i>
                    <span class="menu-label">Riwayat Disposisi</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>

        <!-- Persetujuan ACC -->
        <?php if (in_array($role, ['pimpinan', 'admin_rektorat'])): ?>
            <div class="menu-category">Persetujuan</div>
            <a href="<?= BASE_URL ?>/persetujuan/index.php" class="menu-item <?= $is_acc_active ? 'active' : '' ?>" title="Persetujuan Surat (ACC)">
                <i class="bi bi-patch-check-fill"></i>
                <span class="menu-label">Persetujuan ACC</span>
                <?php if ($badge_acc > 0): ?>
                    <span class="menu-badge" title="<?= $badge_acc ?> menunggu ACC"><?= $badge_acc ?></span>
                <?php endif; ?>
            </a>
        <?php endif; ?>

        <!-- Arsip & Laporan -->
        <div class="menu-category">Arsip &amp; Laporan</div>
        <a href="<?= BASE_URL ?>/arsip/index.php" class="menu-item <?= $is_arsip_active ? 'active' : '' ?>" title="Arsip &amp; Pencarian">
            <i class="bi bi-archive-fill"></i>
            <span class="menu-label">Arsip &amp; Pencarian</span>
        </a>
        <a href="<?= BASE_URL ?>/laporan/index.php" class="menu-item <?= $is_laporan_active ? 'active' : '' ?>" title="Rekap &amp; Laporan">
            <i class="bi bi-file-earmark-bar-graph-fill"></i>
            <span class="menu-label">Rekap &amp; Laporan</span>
        </a>
        <a href="<?= BASE_URL ?>/penomoran/index.php" class="menu-item <?= $is_penomoran_active ? 'active' : '' ?>" title="Pengaturan Penomoran Surat">
            <i class="bi bi-hash"></i>
            <span class="menu-label">Penomoran Surat</span>
        </a>

        <!-- Master Data (Admin Rektorat) -->
        <?php if ($role === 'admin_rektorat'): ?>
            <div class="menu-category">Master Data</div>
            <a href="<?= BASE_URL ?>/master/unit.php" class="menu-item <?= $is_master_unit ? 'active' : '' ?>">
                <i class="bi bi-diagram-3-fill"></i>
                <span class="menu-label">Data Unit Kampus</span>
            </a>
            <a href="<?= BASE_URL ?>/master/kategori.php" class="menu-item <?= $is_master_kat ? 'active' : '' ?>">
                <i class="bi bi-tags-fill"></i>
                <span class="menu-label">Kategori Surat</span>
            </a>
            <a href="<?= BASE_URL ?>/master/jenis.php" class="menu-item <?= $is_master_jenis ? 'active' : '' ?>">
                <i class="bi bi-file-earmark-text-fill"></i>
                <span class="menu-label">Jenis Surat</span>
            </a>
            <a href="<?= BASE_URL ?>/master/format_nomor.php" class="menu-item <?= $is_master_nomor ? 'active' : '' ?>">
                <i class="bi bi-hash"></i>
                <span class="menu-label">Format Nomor Otomatis</span>
            </a>
            <a href="<?= BASE_URL ?>/pengguna/index.php" class="menu-item <?= $is_pengguna ? 'active' : '' ?>">
                <i class="bi bi-people-fill"></i>
                <span class="menu-label">Kelola Pengguna</span>
            </a>
        <?php endif; ?>
    </div>

    <!-- Sidebar Footer -->
    <div class="sidebar-footer">
        <div class="user-badge">
            <div class="user-avatar">
                <i class="bi bi-person-fill"></i>
            </div>
            <div class="user-info">
                <div class="user-name" title="<?= htmlspecialchars($user_name) ?>"><?= htmlspecialchars($user_name) ?></div>
                <div class="user-role"><?= htmlspecialchars(ucwords(str_replace('_', ' ', $role))) ?></div>
            </div>
        </div>
    </div>
</aside>

<script>
// Menjaga posisi scroll sidebar agar tetap konsisten saat berpindah halaman
(function() {
    var sidebar = document.querySelector('.sidebar-menu');
    if (!sidebar) return;
    var savedPos = sessionStorage.getItem('arsita_sidebar_scroll_pos');
    if (savedPos !== null) {
        sidebar.scrollTop = parseInt(savedPos, 10);
    }
    sidebar.addEventListener('scroll', function() {
        sessionStorage.setItem('arsita_sidebar_scroll_pos', sidebar.scrollTop);
    });
})();
</script>
