<?php
// includes/functions.php - Helper utilitas ARSITA

/**
 * Format tanggal ke format Indonesia: 11 Oktober 2026
 */
function tgl_indo($tanggal)
{
    if (!$tanggal || $tanggal == '0000-00-00') return '-';
    $bulan = [
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    $pecahkan = explode('-', date('Y-m-d', strtotime($tanggal)));
    return (int)$pecahkan[2] . ' ' . $bulan[(int)$pecahkan[1]] . ' ' . $pecahkan[0];
}

/**
 * Format status badge dengan style warna modern
 */
function badge_status($status)
{
    $map = [
        // Status surat keluar
        'draft'            => ['bg' => '#f1f5f9', 'text' => '#475569', 'label' => 'Draft'],
        'menunggu_acc'     => ['bg' => '#fef3c7', 'text' => '#d97706', 'label' => 'Menunggu ACC'],
        'revisi'           => ['bg' => '#fee2e2', 'text' => '#dc2626', 'label' => 'Revisi Diperlukan'],
        'disetujui'        => ['bg' => '#dcfce7', 'text' => '#16a34a', 'label' => 'Disetujui'],
        'terkirim'         => ['bg' => '#e0e7ff', 'text' => '#4338ca', 'label' => 'Terkirim'],
        'diarsipkan'       => ['bg' => '#e2e8f0', 'text' => '#334155', 'label' => 'Diarsipkan'],

        // Status surat masuk
        'belum_ditinjau'   => ['bg' => '#fef3c7', 'text' => '#d97706', 'label' => 'Belum Ditinjau'],
        'ditinjau'         => ['bg' => '#e0f2fe', 'text' => '#0284c7', 'label' => 'Ditinjau Pimpinan'],
        'didisposisikan'   => ['bg' => '#f3e8ff', 'text' => '#7e22ce', 'label' => 'Didisposisikan'],

        // Status disposisi
        'belum_diproses'   => ['bg' => '#fee2e2', 'text' => '#b91c1c', 'label' => 'Belum Diproses'],
        'diproses'         => ['bg' => '#fef3c7', 'text' => '#b45309', 'label' => 'Sedang Diproses'],
        'selesai'          => ['bg' => '#dcfce7', 'text' => '#15803d', 'label' => 'Selesai'],

        // Sifat surat
        'biasa'            => ['bg' => '#f1f5f9', 'text' => '#475569', 'label' => 'Biasa'],
        'segera'           => ['bg' => '#fef3c7', 'text' => '#b45309', 'label' => 'Segera'],
        'sangat_segera'    => ['bg' => '#fee2e2', 'text' => '#b91c1c', 'label' => 'Sangat Segera'],
        'penting'          => ['bg' => '#ffedd5', 'text' => '#c2410c', 'label' => 'Penting'],
        'rahasia'          => ['bg' => '#fce7f3', 'text' => '#be185d', 'label' => 'Rahasia'],
    ];

    $item = $map[$status] ?? ['bg' => '#f1f5f9', 'text' => '#475569', 'label' => ucfirst($status)];
    return "<span style=\"display: inline-block; padding: 4px 10px; font-size: 12px; font-weight: 600; border-radius: 9999px; background-color: {$item['bg']}; color: {$item['text']};\">{$item['label']}</span>";
}

/**
 * Notifikasi Flash Session
 */
function set_flash($tipe, $pesan)
{
    $_SESSION['flash'] = ['tipe' => $tipe, 'pesan' => $pesan];
}

function get_flash()
{
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Logika Inti Penomoran Otomatis ARSITA
 * Kombinasi: unit_id + jenis_surat_id + tahun
 * Menggunakan transaksi dan lock untuk menjamin tidak bentrok
 */
function generate_nomor_surat(PDO $pdo, $id_surat_keluar, $id_unit, $id_jenis_surat, $tahun = null, $kategori_id = null)
{
    if (!$tahun) $tahun = (int)date('Y');

    // 1. Ambil format nomor untuk unit dan jenis surat ini (dan kategori jika ada spesifik)
    // Cek format spesifik dengan kategori terlebih dahulu jika ada kategori_id
    $formatRow = null;
    if ($kategori_id) {
        $stmtFmtKat = $pdo->prepare("
            SELECT * FROM format_nomor 
            WHERE id_unit = ? AND id_jenis_surat = ? AND kategori_id = ? AND aktif = 1 
            LIMIT 1
        ");
        $stmtFmtKat->execute([$id_unit, $id_jenis_surat, $kategori_id]);
        $formatRow = $stmtFmtKat->fetch();
    }

    // Jika belum ketemu atau kategori_id null, cari format umum (kategori_id IS NULL)
    if (!$formatRow) {
        $stmtFmt = $pdo->prepare("
            SELECT * FROM format_nomor 
            WHERE id_unit = ? AND id_jenis_surat = ? AND (kategori_id IS NULL OR kategori_id = 0) AND aktif = 1 
            LIMIT 1
        ");
        $stmtFmt->execute([$id_unit, $id_jenis_surat]);
        $formatRow = $stmtFmt->fetch();
    }

    // Default template jika belum disetel sama sekali
    $templateFormat = $formatRow ? $formatRow['format_nomor'] : '{nomor}/{kode_jenis}/{kode_unit}/{tahun}';
    $nomorTerakhirAwal = $formatRow ? (int)($formatRow['nomor_terakhir'] ?? 0) : 0;

    // Ambil info kode unit dan kode jenis surat
    $stmtU = $pdo->prepare("SELECT kode_unit FROM units WHERE id_unit = ?");
    $stmtU->execute([$id_unit]);
    $kodeUnit = $stmtU->fetchColumn() ?: 'UN.14';

    $stmtJ = $pdo->prepare("SELECT kode_jenis FROM jenis_surat WHERE id_jenis_surat = ?");
    $stmtJ->execute([$id_jenis_surat]);
    $kodeJenis = $stmtJ->fetchColumn() ?: 'SRT';

    // 2. Hitung jumlah surat keluar yang sudah terbit di sistem untuk kombinasi ini
    if ($kategori_id && $formatRow && !empty($formatRow['kategori_id'])) {
        $stmtCount = $pdo->prepare("
            SELECT COUNT(*) 
            FROM nomor_surat 
            WHERE id_unit = ? AND id_jenis_surat = ? AND kategori_id = ? AND tahun = ?
            FOR UPDATE
        ");
        $stmtCount->execute([$id_unit, $id_jenis_surat, $kategori_id, $tahun]);
    } else {
        $stmtCount = $pdo->prepare("
            SELECT COUNT(*) 
            FROM nomor_surat 
            WHERE id_unit = ? AND id_jenis_surat = ? AND tahun = ?
            FOR UPDATE
        ");
        $stmtCount->execute([$id_unit, $id_jenis_surat, $tahun]);
    }

    $jumlahSuratSistem = (int)$stmtCount->fetchColumn();

    // Urutan = Starting Number (nomor_terakhir awal) + jumlah surat yang sudah terbit + 1
    $urutan = $nomorTerakhirAwal + $jumlahSuratSistem + 1;

    $nomorTigaDigit = str_pad($urutan, 3, '0', STR_PAD_LEFT);

    // Ganti placeholder template
    $nomorFinal = str_replace(
        ['{nomor}', '{kode_jenis}', '{kode_unit}', '{tahun}'],
        [$nomorTigaDigit, $kodeJenis, $kodeUnit, $tahun],
        $templateFormat
    );

    // 3. Simpan ke tabel nomor_surat
    $stmtInsertNomor = $pdo->prepare("
        INSERT INTO nomor_surat (id_surat_keluar, nomor_surat, tanggal_nomor, tahun, id_unit, id_jenis_surat, kategori_id)
        VALUES (?, ?, CURDATE(), ?, ?, ?, ?)
    ");
    $stmtInsertNomor->execute([$id_surat_keluar, $nomorFinal, $tahun, $id_unit, $id_jenis_surat, $kategori_id]);

    return $nomorFinal;
}

/**
 * Handle Upload File aman
 */
function upload_lampiran($fileInput, $subfolder = 'surat_masuk')
{
    if (!isset($_FILES[$fileInput]) || $_FILES[$fileInput]['error'] !== UPLOAD_ERR_OK) {
        return null;
    }

    $file = $_FILES[$fileInput];
    if ($file['size'] > MAX_FILE_SIZE) {
        throw new Exception("Ukuran file terlalu besar! Maksimal 5MB.");
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
    if (!in_array($ext, $allowed)) {
        throw new Exception("Format file tidak didukung! Format yang dibolehkan: PDF, JPG, PNG, DOC/DOCX.");
    }

    $dir = UPLOAD_PATH . $subfolder . '/';
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }

    $filename = time() . '_' . uniqid() . '.' . $ext;
    $targetPath = $dir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        throw new Exception("Gagal mengunggah file.");
    }

    return $filename;
}
